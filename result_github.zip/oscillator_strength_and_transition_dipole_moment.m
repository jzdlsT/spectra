%%计算振子强度以及跃迁偶极矩
%提取数据
folderpath = pwd;
data=readcell("molar_extinction_coefficient.xlsx");
data{1,1}=[];

%cal
set(0, 'DefaultFigureWindowState', 'maximized');
ed=length(data(1,:));
data{1,ed+1}="f";
data{1,ed+2}="μ";
c=1;
% c=3*10^10;
for i=2:1:length(data(1,:))
    if(data{1,i}=="k")
        e=cell2mat(data(2:end,i));
    end
end

[emax, id] = max(e);
lf = find(e(1:id-1) <= emax/2, 1, 'last');
rt = find(e(id+1:end) <= emax/2, 1, 'first')+id;
omax=double(data{id+1,1});
lo=double(data{lf+1,1});
ro=double(data{rt+1,1});
vl=c/lo*10^7;
vr=c/ro*10^7;
f=4.3*10^-9*emax*(vl-vr);
u=sqrt(0.0092*emax*(ro-lo)/omax);
data{2,ed+1}=f;
data{2,ed+2}=u;

%write
delete('oscillator_strength_and_transition_dipole_moment.xlsx'); 
writecell(data,'oscillator_strength_and_transition_dipole_moment.xlsx');
mergepath = fullfile(folderpath,'oscillator_strength_and_transition_dipole_moment.xlsx');
excelApp = actxserver('Excel.Application');
workbook = excelApp.Workbooks.Open(mergepath);
worksheet = workbook.Sheets.Item(1);
worksheet.Range('A:A').HorizontalAlignment = -4108;
worksheet.Range('1:1').HorizontalAlignment = -4108;
worksheet.Columns.ColumnWidth=13;
worksheet.Rows.RowHeight=15;
workbook.Save();
excelApp.Quit();
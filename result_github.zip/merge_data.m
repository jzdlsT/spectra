%%合并数据到同一个文件
%指定文件夹路径
cd('data');
folderpath = pwd;

%get
filelist = dir(fullfile(pwd,'*.xlsx'));
cd ..  % 回退到上一级目录

%sort
filename = {filelist.name};
[sortedname,sortedid] = sort_nat(filename);
filelist = filelist(sortedid);

%merge
mergefile={};
data = readmatrix(fullfile(folderpath,filelist(1).name));
bg=find(data(:,1)>=400,1,'first');
ed=find(data(:,1)<=800,1,'last');
mergefile(2:2+(ed-bg),1) = num2cell(data(bg:ed,1));
for i=1:length(filelist)
    mergefile{1,i+1} = regexprep(filelist(i).name, '\.xlsx$', '');
    data=readmatrix(fullfile(folderpath,filelist(i).name));
    %降噪
    data(bg:ed,3) = imgaussfilt(data(bg:ed,3));
    mergefile(2:2+(ed-bg),i+1)=num2cell(data(bg:ed,3));
end

%write
delete('merge_data.xlsx'); 
writecell(mergefile,'merge_data.xlsx');
mergepath = fullfile(fileparts(folderpath),'merge_data.xlsx');
excelApp = actxserver('Excel.Application');
workbook = excelApp.Workbooks.Open(mergepath);
worksheet = workbook.Sheets.Item(1);
worksheet.Range('A:A').HorizontalAlignment = -4108;
worksheet.Range('1:1').HorizontalAlignment = -4108;
worksheet.Columns.ColumnWidth=13;
worksheet.Rows.RowHeight=15;
workbook.Save();
excelApp.Quit();


currentFolder = fileparts(mfilename('fullpath'));

cd(currentFolder);

disp(pwd);

run('merge_data.m');
run('data_processing.m');
run('molar_extinction_coefficient.m');
run('oscillator_strength_and_transition_dipole_moment.m');
run('separate_absorption_peaks.m');
run('dimer_dissociation_constant.m');
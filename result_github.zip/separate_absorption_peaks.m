%%分离吸收峰
%提取数据
folderpath = pwd;
data=readcell("oscillator_strength_and_transition_dipole_moment.xlsx");
data{1,1}=[];

%cal
set(0, 'DefaultFigureWindowState', 'maximized');
ed=length(data(1,:));
data{1,ed+1}="ε_M";
data{1,ed+2}="ε_D";

for i = 2:1:length(data(1,:))
    if(data{1,i} == "k")
        e = cell2mat(data(2:end,i));
    end
end
% 假设你已经有了数据
x = cell2mat(data(2:end, 1));  % 将第一列数据转换为数值型（波长等）
y = e;  % 吸光度数据（或者你实际的响应数据）

% 自定义双高斯模型
gauss2 = @(params, x) params(1)*exp(-((x - params(2))/params(3)).^2) + ...
                       params(4)*exp(-((x - params(5))/params(6)).^2);

% 初始猜测参数 [A1, μ1, σ1, A2, μ2, σ2]
initial_guess = [47507, 600, 30, 885300, 660, 20];

% 设置优化选项
opts = optimset('MaxFunEvals', 10000, 'MaxIter', 10000);

% 使用 fminsearch 进行拟合
params_fit = fminsearch(@(params) sum((y - gauss2(params, x)).^2), initial_guess, opts);

% 提取拟合结果
A1 = params_fit(1);  % 第一个峰的幅度
mu1 = params_fit(2);  % 第一个峰的中心位置
sigma1 = params_fit(3);  % 第一个峰的宽度
A2 = params_fit(4);  % 第二个峰的幅度
mu2 = params_fit(5);  % 第二个峰的中心位置
sigma2 = params_fit(6);  % 第二个峰的宽度

% 计算每个高斯峰
y1 = A1 * exp(-((x - mu1) / sigma1).^2);  % 第一个高斯峰
y2 = A2 * exp(-((x - mu2) / sigma2).^2);  % 第二个高斯峰
y_fit = gauss2(params_fit, x);  % 使用拟合参数计算拟合曲线

% 绘制结果
figure(5); clf(5);
plot(x, y, 'b.', 'MarkerSize', 10);  % 原始数据（带噪声）
hold on;
plot(x, y1, 'r-', 'LineWidth', 2);  % 第一个高斯峰（红色实线）
plot(x, y2, 'g-', 'LineWidth', 2);  % 第二个高斯峰（绿色实线）
plot(x, y_fit, 'k-', 'LineWidth', 2);  % 拟合曲线（黑色实线）

% 添加标注在第一个高斯峰下方
offset = 0.03 * (max(y) - min(y));  % 偏移量为 y 轴范围的 5%
text(mu1 - 0.1 * (x(end) - x(1)), A1 , sprintf('A_1=%.2f\nμ_1=%.2f\nσ_1=%.2f', A1, mu1, sigma1), ...
    'Color', 'red', 'FontSize', 10, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top');

% 添加标注在第二个高斯峰上方
text(mu2 + 0.1 * (x(end) - x(1)), A2 , sprintf('A_2=%.2f\nμ_2=%.2f\nσ_2=%.2f', A2, mu2, sigma2), ...
    'Color', 'green', 'FontSize', 10, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');

hold off;

% 添加图例、标题、标签等
legend('原始数据', '高斯峰1', '高斯峰2', '拟合', 'FontSize', 16);
title('消光系数双峰拟合', 'FontSize', 16);
xlabel('波长λ/nm', 'FontSize', 16);
ylabel('消光系数ε(υ)/L·mol⁻¹·cm⁻¹', 'FontSize', 16);

% 保存图像
saveas(gca,"消光系数双峰拟合.bmp");
% exportgraphics(gcf,"消光系数双峰拟合.png", 'Resolution', 1500);
% savefig(figure(5),"消光系数双峰拟合.fig");

y=y2;A=A2;u=mu2;o=sigma2;
lf = find(y(:) >= A/2, 1, 'first');
rt = find(y(:) >= A/2, 1, 'last');
lf=x(lf,1);rt=x(rt,1);
f=4.3*10^-9*A*(1/lf-1/rt)*10^7;
u=sqrt(0.0092*A*(rt-lf)/u);
data{3,ed-1}=f;
data{3,ed}=u;
data{2,ed+1}=A2;
data{2,ed+2}=A1;
disp({f,u,A2,A1});
for i=4:1:down
    data{i,ed-1}=[];
    data{i,ed}=[];
end
%write
delete('separate_absorption_peaks.xlsx'); 
writecell(data,'separate_absorption_peaks.xlsx');
mergepath = fullfile(folderpath,'separate_absorption_peaks.xlsx');
excelApp = actxserver('Excel.Application');
workbook = excelApp.Workbooks.Open(mergepath);
worksheet = workbook.Sheets.Item(1);
worksheet.Range('A:A').HorizontalAlignment = -4108;
worksheet.Range('1:1').HorizontalAlignment = -4108;
worksheet.Columns.ColumnWidth=13;
worksheet.Rows.RowHeight=15;
workbook.Save();
excelApp.Quit();

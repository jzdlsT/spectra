%%计算摩尔消光系数
%提取数据
folderpath = pwd;
data=readcell("merge_data.xlsx");
data{1,1}=[];

%cal
set(0, 'DefaultFigureWindowState', 'maximized');
v=cell2mat(data(2:end,1));
bg=2;ed=length(data(1,:));
c=cellfun(@(x)str2double(regexp(x,'\d+(\.\d+)?','match')),data(1,2:ed))';
data{1,ed+1}="b";
data{1,ed+2}="k";
data{1,ed+3}="R^2";
data{1,ed+4}="p";
for i=2:length(data(:,1))
    Y=cell2mat(data(i,2:end))';
    X = [ones(length(c),1) c];
    [b,bint,r,rint,states]=regress(Y,X);
    data{i,ed+1}=b(1);
    data{i,ed+2}=b(2)*10^6;
    data{i,ed+3}=states(1);
    data{i,ed+4}=states(3);
end
figure(4);clf(4);
x=cell2mat(data(2:end,1))';
y=cell2mat(data(2:end,ed+2))';
figure(4);
plot(x,y, 'LineWidth', 2);
title("λ-ε(υ)",'FontSize',16);
xlabel('波长λ/nm','FontSize',16);
ylabel('归一化消光系数ε(υ)/L·mol⁻¹·cm⁻¹','FontSize',16);
saveas(gca,"λ-ε(ν).bmp");
% exportgraphics(gcf,"λ-ε(ν).png", 'Resolution', 1500);
% savefig(figure(4),"λ-ε(ν).fig");

%write
delete('molar_extinction_coefficient.xlsx'); 
writecell(data,'molar_extinction_coefficient.xlsx');
mergepath = fullfile(folderpath,'molar_extinction_coefficient.xlsx');
excelApp = actxserver('Excel.Application');
workbook = excelApp.Workbooks.Open(mergepath);
worksheet = workbook.Sheets.Item(1);
worksheet.Range('A:A').HorizontalAlignment = -4108;
worksheet.Range('1:1').HorizontalAlignment = -4108;
worksheet.Columns.ColumnWidth=13;
worksheet.Rows.RowHeight=15;
workbook.Save();
excelApp.Quit();

%% 二聚体解离常数
% 提取数据
folderpath = pwd;
data = readcell("separate_absorption_peaks.xlsx");
data{1, 1} = [];

% 计算
% set(0, 'DefaultFigureWindowState', 'maximized');
% figure(6); clf(6);
ed = length(data(1, :));
lg = length(data(:, 1));
x = cell2mat(data(2:end, 1));
data{lg+1,1}="α";
data{lg+2,1}="K";
data{lg+3,1}="v_M";
data{lg+4,1}="A_M";
data{lg+5,1}="vv_M";
data{lg+6,1}="v_D";
data{lg+7,1}="A_D";
data{lg+8,1}="vv_D";
e_M=cell2mat(data(2,ed-1));
e_D=cell2mat(data(2,ed));

% 预定义 y 的全局最大值和最小值
y_min = inf;
y_max = -inf;

% 第一步：计算全局 y 轴范围
for i = 2:1:ed-8
    y = cell2mat(data(2:end, i));
    y_min = min(y_min, min(y));  % 更新全局最小值
    y_max = max(y_max, max(y));  % 更新全局最大值
end
y_max = y_max + 0.2;
y_min = y_min - 0.2;

% 第二步：绘图并统一 y 轴范围
for i = 2:1:ed-8
    name = string(data(1, i));
    y = cell2mat(data(2:end, i));

    % 自定义双高斯模型
    gauss2 = @(params, x) params(1) * exp(-((x - params(2)) / params(3)).^2) + ...
                           params(4) * exp(-((x - params(5)) / params(6)).^2);

    % 初始猜测参数 [A1, μ1, σ1, A2, μ2, σ2]
    id1 = find(x(:) >= 600, 1, 'first');
    id2 = find(x(:) >= 660, 1, 'first');
    initial_guess = [y(id1, 1), 600, 30, y(id2, 1), 660, 20];

    % 设置优化选项
    opts = optimset('MaxFunEvals', 10000, 'MaxIter', 10000);

    % 使用 fminsearch 进行拟合
    params_fit = fminsearch(@(params) sum((y - gauss2(params, x)).^2), initial_guess, opts);

    % 提取拟合结果
    A1 = params_fit(1);
    mu1 = params_fit(2);
    sigma1 = params_fit(3);
    A2 = params_fit(4);
    mu2 = params_fit(5);
    sigma2 = params_fit(6);

    %计算其他
    A_M=A2;A_D=A1;
    C_M=A_M/e_M;
    C_D=A_D/e_D;
    alpha=C_M/(C_M+2*C_D);
    K=C_M^2/C_D;
    data{lg+1,i}=alpha;
    data{lg+2,i}=K;

    % 计算每个高斯峰
    y1 = A1 * exp(-((x - mu1) / sigma1).^2);
    y2 = A2 * exp(-((x - mu2) / sigma2).^2);

    A=max(y2);
    [maxValue, maxIndex] = max(y2);
    % disp({i,":"});
    % disp(A);
    % disp({maxValue, maxIndex});
    % disp(x(maxIndex,1));
    lf = find(y2 >= A/2, 1, 'first');
    rt = find(y2 >= A/2, 1, 'last');
    % disp(x(rt,1)-x(lf,1));
    data{lg+3,i}=x(maxIndex,1);
    data{lg+4,i}=A;
    data{lg+5,i}=x(rt,1)-x(lf,1);

    A=max(y1);
    [maxValue, maxIndex] = max(y1);
    % disp({i,":"});
    % disp(A);
    % disp({maxValue, maxIndex});
    % disp(x(maxIndex,1));
    lf = find(y1 >= A/2, 1, 'first');
    rt = find(y1 >= A/2, 1, 'last');
    % disp(x(rt,1)-x(lf,1));
    data{lg+6,i}=x(maxIndex,1);
    data{lg+7,i}=A;
    data{lg+8,i}=x(rt,1)-x(lf,1);


    y_fit = gauss2(params_fit, x);

    % 绘制结果
    plot(x, y, 'b.', 'MarkerSize', 10);
    hold on;
    plot(x, y1, 'r-', 'LineWidth', 2);
    plot(x, y2, 'g-', 'LineWidth', 2);
    plot(x, y_fit, 'k-', 'LineWidth', 2);

    % 将标签放到第一个峰的正左边
    text(mu1 - 0.1 * (x(end) - x(1)), A1 , sprintf('A_1=%.2f\nμ_1=%.2f\nσ_1=%.2f', A1, mu1, sigma1), ...
        'Color', 'red', 'FontSize', 10, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');

    % 将标签放到第二个峰的正右边
    text(mu2 + 0.1 * (x(end) - x(1)), A2 , sprintf('A_2=%.2f\nμ_2=%.2f\nσ_2=%.2f', A2, mu2, sigma2), ...
        'Color', 'green', 'FontSize', 10, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');

    hold off;

    % 统一 y 轴范围
    ylim([y_min, y_max]);

    % 添加图例、标题、标签等
    legend('原始数据', '高斯峰1', '高斯峰2', '拟合', 'FontSize', 16);
    name = name + '消光度双峰拟合';
    title(name, 'FontSize', 16);
    xlabel('波长λ/nm', 'FontSize', 16);
    ylabel('消光度ε', 'FontSize', 16);
    saveas(gca, name + ".bmp");
    % exportgraphics(gcf,name+".png", 'Resolution', 1500);
    % savefig(figure(6),name+".fig");
end

% 假设 data 是包含 missing 元素的元胞数组
for i = 1:numel(data)
    if ismissing(data{i})
        data{i} = NaN;  % 将 missing 转换为 NaN，或者你可以选择其他值
    end
end

%write
delete('dimer_dissociation_constant.xlsx'); 
writecell(data,'dimer_dissociation_constant.xlsx');
mergepath = fullfile(folderpath,'dimer_dissociation_constant.xlsx');
excelApp = actxserver('Excel.Application');
workbook = excelApp.Workbooks.Open(mergepath);
worksheet = workbook.Sheets.Item(1);
worksheet.Range('A:A').HorizontalAlignment = -4108;
worksheet.Range('1:1').HorizontalAlignment = -4108;
worksheet.Columns.ColumnWidth=13;
worksheet.Rows.RowHeight=15;
workbook.Save();
excelApp.Quit();


% delete('result.xlsx'); 
% writecell(data,'result.xlsx');
% mergepath = fullfile(folderpath,'result.xlsx');
% excelApp = actxserver('Excel.Application');
% workbook = excelApp.Workbooks.Open(mergepath);
% worksheet = workbook.Sheets.Item(1);
% worksheet.Range('A:A').HorizontalAlignment = -4108;
% worksheet.Range('1:1').HorizontalAlignment = -4108;
% worksheet.Columns.ColumnWidth=13;
% worksheet.Rows.RowHeight=15;
% workbook.Save();
% excelApp.Quit();
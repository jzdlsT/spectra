%%作图
%提取数据
% folderpath = 'C:\TJZ\WHU\curriculum\Seminar';
folderpath = pwd;
data=readcell("merge_data.xlsx");
data{1,1}=[];

%figure
set(0, 'DefaultFigureWindowState', 'maximized');
figure(1);clf(1);
figure(2);clf(2);
figure(3);clf(3);
x=cell2mat(data(2:end,1));
y=cell2mat(data(2:end,2:end));
color=distinguishable_colors(size(y,2));
lable={};
for i=1:size(y,2)
    picturename=sprintf(cell2mat(data(1,i+1)));
    concentration = str2double(regexp(picturename, '-?\d+(\.\d+)?', 'match', 'once'));
    lable(i,1)=cellstr(picturename);
    
    figure(1);
    plot(x,y(:,i),'Color',color(i,:),'LineWidth',1);
    title(picturename+"的λ-ε曲线(降噪后)",'FontSize',16);
    xlabel('波长λ/nm','FontSize',16);
    ylabel('消光度ε','FontSize',16);
    saveas(gca,picturename+"(降噪后).bmp");
    % exportgraphics(gcf,picturename+"(降噪后).png", 'Resolution', 1500);
    % savefig(figure(1),picturename+"(降噪后).fig");

    figure(2)
    plot(x,y(:,i),'Color',color(i,:),'LineWidth',1);
    hold on;


    figure(3)
    plot(x,y(:,i)/concentration,'Color',color(i,:),'LineWidth',1);
    hold on;
end

figure(2)
title("整体λ-ε曲线(降噪后)",'FontSize', 16);
xlabel('波长λ/nm','FontSize', 16);
ylabel('消光度ε','FontSize', 16);
legend(lable,'Location','best', 'FontSize', 16);
saveas(gca,"sum(降噪后).bmp");
% exportgraphics(gcf,"sum(降噪后).png", 'Resolution', 1500);
% savefig(figure(2),"sum(降噪后).fig");

figure(3)
title("整体λ-ε/c曲线(降噪后)",'FontSize', 16);
xlabel('波长λ/nm','FontSize', 16);
ylabel('消光度/浓度ε/c','FontSize', 16);
legend(lable,'Location','best', 'FontSize', 16);
saveas(gca,"sum1(降噪后).bmp");
% exportgraphics(gcf,"sum1(降噪后).png", 'Resolution', 1500);
% savefig(figure(3),"sum1(降噪后).fig");

